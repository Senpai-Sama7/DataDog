# Minimal Metadata (ICPSR-inspired)

- **Title**: 
- **Description**: 
- **Creators / PI**: 
- **Version / Version Date**: 
- **Universe (Population described)**: 
- **Unit of Analysis**: 
- **Geographic Coverage**: 
- **Time Coverage (Dates of data collection)**: 
- **Variables**: 
- **Methods (Collection Mode)**: 
- **Provenance (Source, transformations, code)**: 
- **Caveats / Limitations**: 
- **License**: CC BY 4.0