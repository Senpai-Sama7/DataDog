# Module 3.3 — Pivot Lab Instructions

Build a pivot showing Sales by Region by Month, then add:
- Percent-of-total view
- Conditional formatting for highest month
- A 'Formulas' tab listing any helper formulas used

Source data: `pivot_starter.xlsx` sheet `Raw` or `sales_sample.csv`